﻿CREATE PROCEDURE [dbo].[spAudit_FilterByDate]
	@DateFrom DATETIME2,
	@DateTo DATETIME2
AS
BEGIN
	SELECT CurFrom, CurTo, StartVal, ConvertedVal, ConversionDate
	FROM [dbo].[Audit]
	WHERE ConversionDate BETWEEN @DateFrom AND @DateTo
END
