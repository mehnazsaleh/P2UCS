﻿CREATE TABLE [dbo].[Audit]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY,
    [CurFrom] NCHAR(10) NULL, 
    [CurTo] NCHAR(10) NULL, 
    [StartVal] DECIMAL(12, 5) NULL, 
    [ConvertedVal] DECIMAL(12, 5) NULL, 
    [ConversionDate] DATETIME2 NOT NULL DEFAULT GetDate()
)
