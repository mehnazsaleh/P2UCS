﻿CREATE TABLE [dbo].[Rates]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY,
    [Currency] NCHAR(10) NULL,
    [Rate] DECIMAL(12, 5) NULL
)
