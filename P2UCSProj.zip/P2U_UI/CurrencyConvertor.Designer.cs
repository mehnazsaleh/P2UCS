﻿namespace P2UUI
{
    partial class CurrencyConvertor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtCurFrom = new System.Windows.Forms.TextBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cmbCurFrom = new System.Windows.Forms.ComboBox();
            this.lblArrow = new System.Windows.Forms.Label();
            this.txtCurTo = new System.Windows.Forms.TextBox();
            this.cmbCurTo = new System.Windows.Forms.ComboBox();
            this.btnConvert = new System.Windows.Forms.Button();
            this.tcCurrencyConvertor = new System.Windows.Forms.TabControl();
            this.tpCurCon = new System.Windows.Forms.TabPage();
            this.lblCurConTab = new System.Windows.Forms.Label();
            this.tpAudit = new System.Windows.Forms.TabPage();
            this.dtpTo = new System.Windows.Forms.DateTimePicker();
            this.dtpFrom = new System.Windows.Forms.DateTimePicker();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.dgvAudit = new System.Windows.Forms.DataGridView();
            this.auditBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lblAmount = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.auditBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.p2UCSDBDataSet = new P2UUI.P2UCSDBDataSet();
            this.auditTableAdapter = new P2UUI.P2UCSDBDataSetTableAdapters.AuditTableAdapter();
            this.p2UCSDBDataSet1 = new P2UUI.P2UCSDBDataSet1();
            this.ratesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ratesTableAdapter = new P2UUI.P2UCSDBDataSet1TableAdapters.RatesTableAdapter();
            this.tcCurrencyConvertor.SuspendLayout();
            this.tpCurCon.SuspendLayout();
            this.tpAudit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAudit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.auditBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.auditBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2UCSDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2UCSDBDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ratesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // txtCurFrom
            // 
            this.txtCurFrom.Location = new System.Drawing.Point(27, 96);
            this.txtCurFrom.Name = "txtCurFrom";
            this.txtCurFrom.Size = new System.Drawing.Size(100, 20);
            this.txtCurFrom.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(7, 8);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(270, 31);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "Currency Convertor";
            // 
            // cmbCurFrom
            // 
            this.cmbCurFrom.FormattingEnabled = true;
            this.cmbCurFrom.Location = new System.Drawing.Point(133, 95);
            this.cmbCurFrom.Name = "cmbCurFrom";
            this.cmbCurFrom.Size = new System.Drawing.Size(76, 21);
            this.cmbCurFrom.TabIndex = 2;
            this.cmbCurFrom.SelectedIndexChanged += new System.EventHandler(this.cmbCurFrom_SelectedIndexChanged);
            // 
            // lblArrow
            // 
            this.lblArrow.AutoSize = true;
            this.lblArrow.Font = new System.Drawing.Font("Cooper Black", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArrow.Location = new System.Drawing.Point(214, 82);
            this.lblArrow.Name = "lblArrow";
            this.lblArrow.Size = new System.Drawing.Size(44, 42);
            this.lblArrow.TabIndex = 3;
            this.lblArrow.Text = "→";
            // 
            // txtCurTo
            // 
            this.txtCurTo.Location = new System.Drawing.Point(426, 96);
            this.txtCurTo.Name = "txtCurTo";
            this.txtCurTo.Size = new System.Drawing.Size(100, 20);
            this.txtCurTo.TabIndex = 4;
            // 
            // cmbCurTo
            // 
            this.cmbCurTo.FormattingEnabled = true;
            this.cmbCurTo.Location = new System.Drawing.Point(263, 95);
            this.cmbCurTo.Name = "cmbCurTo";
            this.cmbCurTo.Size = new System.Drawing.Size(76, 21);
            this.cmbCurTo.TabIndex = 5;
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(345, 94);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 23);
            this.btnConvert.TabIndex = 6;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // tcCurrencyConvertor
            // 
            this.tcCurrencyConvertor.Controls.Add(this.tpCurCon);
            this.tcCurrencyConvertor.Controls.Add(this.tpAudit);
            this.tcCurrencyConvertor.Location = new System.Drawing.Point(12, 49);
            this.tcCurrencyConvertor.Name = "tcCurrencyConvertor";
            this.tcCurrencyConvertor.SelectedIndex = 0;
            this.tcCurrencyConvertor.Size = new System.Drawing.Size(563, 293);
            this.tcCurrencyConvertor.TabIndex = 7;
            // 
            // tpCurCon
            // 
            this.tpCurCon.Controls.Add(this.lblAmount);
            this.tpCurCon.Controls.Add(this.lblCurConTab);
            this.tpCurCon.Controls.Add(this.btnConvert);
            this.tpCurCon.Controls.Add(this.txtCurFrom);
            this.tpCurCon.Controls.Add(this.cmbCurTo);
            this.tpCurCon.Controls.Add(this.cmbCurFrom);
            this.tpCurCon.Controls.Add(this.txtCurTo);
            this.tpCurCon.Controls.Add(this.lblArrow);
            this.tpCurCon.Location = new System.Drawing.Point(4, 22);
            this.tpCurCon.Name = "tpCurCon";
            this.tpCurCon.Padding = new System.Windows.Forms.Padding(3);
            this.tpCurCon.Size = new System.Drawing.Size(555, 267);
            this.tpCurCon.TabIndex = 0;
            this.tpCurCon.Text = "Convertor";
            this.tpCurCon.UseVisualStyleBackColor = true;
            // 
            // lblCurConTab
            // 
            this.lblCurConTab.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblCurConTab.Location = new System.Drawing.Point(24, 22);
            this.lblCurConTab.Name = "lblCurConTab";
            this.lblCurConTab.Size = new System.Drawing.Size(499, 46);
            this.lblCurConTab.TabIndex = 7;
            this.lblCurConTab.Text = "Convertor Tool: Enter the amount you would like to convert in the amount field an" +
    "d select the currencies you would like to convert from and to and click the Conv" +
    "ert button.\r\n";
            // 
            // tpAudit
            // 
            this.tpAudit.Controls.Add(this.dtpTo);
            this.tpAudit.Controls.Add(this.dtpFrom);
            this.tpAudit.Controls.Add(this.btnRefresh);
            this.tpAudit.Controls.Add(this.dgvAudit);
            this.tpAudit.Location = new System.Drawing.Point(4, 22);
            this.tpAudit.Name = "tpAudit";
            this.tpAudit.Padding = new System.Windows.Forms.Padding(3);
            this.tpAudit.Size = new System.Drawing.Size(555, 267);
            this.tpAudit.TabIndex = 1;
            this.tpAudit.Text = "Audit";
            this.tpAudit.UseVisualStyleBackColor = true;
            // 
            // dtpTo
            // 
            this.dtpTo.Location = new System.Drawing.Point(161, 20);
            this.dtpTo.Name = "dtpTo";
            this.dtpTo.Size = new System.Drawing.Size(145, 20);
            this.dtpTo.TabIndex = 3;
            // 
            // dtpFrom
            // 
            this.dtpFrom.Location = new System.Drawing.Point(6, 20);
            this.dtpFrom.Name = "dtpFrom";
            this.dtpFrom.Size = new System.Drawing.Size(149, 20);
            this.dtpFrom.TabIndex = 2;
            this.dtpFrom.TabStop = false;
            this.dtpFrom.Value = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(474, 31);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(75, 23);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // dgvAudit
            // 
            this.dgvAudit.AllowUserToAddRows = false;
            this.dgvAudit.AllowUserToDeleteRows = false;
            this.dgvAudit.AutoGenerateColumns = false;
            this.dgvAudit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAudit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dgvAudit.DataSource = this.auditBindingSource1;
            this.dgvAudit.Location = new System.Drawing.Point(6, 60);
            this.dgvAudit.Name = "dgvAudit";
            this.dgvAudit.ReadOnly = true;
            this.dgvAudit.Size = new System.Drawing.Size(543, 201);
            this.dgvAudit.TabIndex = 0;
            // 
            // lblAmount
            // 
            this.lblAmount.AutoSize = true;
            this.lblAmount.Location = new System.Drawing.Point(24, 80);
            this.lblAmount.Name = "lblAmount";
            this.lblAmount.Size = new System.Drawing.Size(43, 13);
            this.lblAmount.TabIndex = 8;
            this.lblAmount.Text = "Amount";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "CurFrom";
            this.dataGridViewTextBoxColumn1.HeaderText = "CurFrom";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "CurTo";
            this.dataGridViewTextBoxColumn2.HeaderText = "CurTo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "StartVal";
            this.dataGridViewTextBoxColumn3.HeaderText = "StartVal";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ConvertedVal";
            this.dataGridViewTextBoxColumn4.HeaderText = "ConvertedVal";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "ConversionDate";
            this.dataGridViewTextBoxColumn5.HeaderText = "ConversionDate";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // auditBindingSource1
            // 
            this.auditBindingSource1.DataMember = "Audit";
            this.auditBindingSource1.DataSource = this.p2UCSDBDataSet;
            // 
            // p2UCSDBDataSet
            // 
            this.p2UCSDBDataSet.DataSetName = "P2UCSDBDataSet";
            this.p2UCSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // auditTableAdapter
            // 
            this.auditTableAdapter.ClearBeforeFill = true;
            // 
            // p2UCSDBDataSet1
            // 
            this.p2UCSDBDataSet1.DataSetName = "P2UCSDBDataSet1";
            this.p2UCSDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ratesBindingSource
            // 
            this.ratesBindingSource.DataMember = "Rates";
            this.ratesBindingSource.DataSource = this.p2UCSDBDataSet1;
            // 
            // ratesTableAdapter
            // 
            this.ratesTableAdapter.ClearBeforeFill = true;
            // 
            // CurrencyConvertor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(587, 354);
            this.Controls.Add(this.tcCurrencyConvertor);
            this.Controls.Add(this.lblTitle);
            this.Name = "CurrencyConvertor";
            this.Text = "Currency Convertor";
            this.Load += new System.EventHandler(this.CurrencyConvertor_Load);
            this.tcCurrencyConvertor.ResumeLayout(false);
            this.tpCurCon.ResumeLayout(false);
            this.tpCurCon.PerformLayout();
            this.tpAudit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAudit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.auditBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.auditBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2UCSDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2UCSDBDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ratesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCurFrom;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.ComboBox cmbCurFrom;
        private System.Windows.Forms.Label lblArrow;
        private System.Windows.Forms.TextBox txtCurTo;
        private System.Windows.Forms.ComboBox cmbCurTo;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.TabControl tcCurrencyConvertor;
        private System.Windows.Forms.TabPage tpCurCon;
        private System.Windows.Forms.TabPage tpAudit;
        private System.Windows.Forms.Label lblCurConTab;
        private System.Windows.Forms.DataGridView dgvAudit;
        private System.Windows.Forms.BindingSource auditBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn curFromDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn curToDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn startValDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn convertedValDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn conversionDateDataGridViewTextBoxColumn;
        private P2UCSDBDataSet p2UCSDBDataSet;
        private System.Windows.Forms.BindingSource auditBindingSource1;
        private P2UCSDBDataSetTableAdapters.AuditTableAdapter auditTableAdapter;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.DateTimePicker dtpTo;
        private System.Windows.Forms.DateTimePicker dtpFrom;
        private P2UCSDBDataSet1 p2UCSDBDataSet1;
        private System.Windows.Forms.BindingSource ratesBindingSource;
        private P2UCSDBDataSet1TableAdapters.RatesTableAdapter ratesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Label lblAmount;
    }
}

