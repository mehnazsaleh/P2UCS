﻿using P2ULibrary;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace P2UUI
{
    public partial class CurrencyConvertor : Form
    {
        private Audit audit = new Audit();
        private Rates rates = new Rates();
        private decimal rateInput = 0.0M;
        private decimal convertedVal = 0.0M;
        private List<String> currencies = new List<String>();
        private List<String> currenciesTo = new List<String>();
        BindingSource ratesFromBinding = new BindingSource();
        BindingSource ratesToBinding = new BindingSource();
        public CurrencyConvertor()
        {
            InitializeComponent();
            SetupData();

            ratesFromBinding.DataSource = currencies;
            cmbCurFrom.DataSource = ratesFromBinding;

            ratesToBinding.DataSource = currenciesTo;
            cmbCurTo.DataSource = ratesToBinding;
        }
        private void SetupData()
        {
            currencies.Add("GBP");

            foreach (ExchangeRate exr in rates.ExchangeRates)
            {
                currencies.Add(exr.Currency);
            }
        }
        private void cmbCurFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Refresh Data in cmbCurTo
            RefreshCurrencyToData();
        }
        private void RefreshCurrencyToData()
        {
            currenciesTo.Clear();
            foreach (String str in currencies)
            {
                if (str != cmbCurFrom.SelectedItem.ToString())
                {
                    currenciesTo.Add(str);
                    ratesToBinding.ResetBindings(false);
                }
            }

        }
        private void RefreshAuditData()
        {
            auditBindingSource1.Filter = string.Format("ConversionDate > '{0}' and ConversionDate <= '{1}'",
                                                        dtpFrom.Value.ToString(), dtpTo.Value.ToString());
            auditBindingSource1.ResetBindings(false);
        }
        private void ConvertCurrency()
        {
            convertedVal = rates.ConvertValue(cmbCurFrom.SelectedItem.ToString(),
                                    cmbCurTo.SelectedItem.ToString(),
                                    rateInput);

            txtCurTo.Text = convertedVal.ToString();

            audit.InsertData(cmbCurFrom.SelectedItem.ToString(), cmbCurTo.SelectedItem.ToString(), rateInput, convertedVal);
        }
        private bool IsInputValid()
        {
            if (Decimal.TryParse(txtCurFrom.Text, out rateInput))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void CurrencyConvertor_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'p2UCSDBDataSet1.Rates' table. You can move, or remove it, as needed.
            this.ratesTableAdapter.Fill(this.p2UCSDBDataSet1.Rates);
            // TODO: This line of code loads data into the 'p2UCSDBDataSet.Audit' table. You can move, or remove it, as needed.
            this.auditTableAdapter.Fill(this.p2UCSDBDataSet.Audit);
        }
        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (IsInputValid() & rateInput > 0)
            {
                ConvertCurrency();
            }
            else
            {
                MessageBox.Show("Please enter a valid amount.");
            }
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshAuditData();
        }
    }
}