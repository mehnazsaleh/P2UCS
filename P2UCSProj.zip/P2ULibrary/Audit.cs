﻿using System;
using System.Data.SqlClient;

namespace P2ULibrary
{
    public class Audit
    {
        public string CurrencyFrom { get; set; }
        public string CurrencyTo { get; set; }
        public double StartVal { get; set; }
        public double ConvertedVal { get; set; }
        public DateTime ConversionDate { get; set; }
        public void InsertData(string curFrom, string curTo, decimal startVal, decimal convertedVal)
        {
            string connectionString;
            SqlConnection cnn;
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql;

            connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=P2UCSDB";
                cnn = new SqlConnection(connectionString);

            cnn.Open();
            
            sql = string.Format("insert into Audit (CurFrom,CurTo,StartVal,ConvertedVal) values('{0}','{1}',{2},{3})",
                                 curFrom, curTo, startVal, convertedVal);
            command = new SqlCommand(sql, cnn);

            adapter.InsertCommand = new SqlCommand(sql, cnn);
            adapter.InsertCommand.ExecuteNonQuery();
            
            cnn.Close();
        }
    }
}