﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace P2ULibrary
{
    public class Rates
    {
        private double rateInput;
        public List<ExchangeRate> ExchangeRates { get; set; }

        public Rates()
        {
            ExchangeRates = new List<ExchangeRate>();
            ReadInRates();
        }

        public decimal ConvertValue(string curFrom, string curTo, decimal startVal)
        {
            //Calculation to allow conversion to and from multiple currencies
            //GBP hardcoded - used as base value for calculation so only one rate per currency required in data structure
            foreach (ExchangeRate exr in ExchangeRates)
            {
                if (curFrom == "GBP" & curTo == exr.Currency)
                {
                    return startVal * (decimal)exr.Rate;
                }
                else if (curTo == "GBP" & curFrom == exr.Currency)
                {
                    return startVal / (decimal)exr.Rate;
                }
                else if (curFrom == exr.Currency)
                {
                    foreach (ExchangeRate exr2 in ExchangeRates)
                    {
                        if (curTo == exr2.Currency)
                        {
                            return (startVal / (decimal)exr.Rate) * (decimal)exr2.Rate;
                        }

                    }
                }
            }
            return 0.0M; //Null value sent if currency exchange rate not found in Db           
        }

        private void ReadInRates()
        {
            //Read in the rates from GBP to any currency with rate
            Console.WriteLine("Reading rates from Db...");

            string connectionString;
            SqlConnection cnn;

            connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=P2UCSDB";

            cnn = new SqlConnection(connectionString);

            cnn.Open();

            Console.WriteLine("Connected");

            SqlCommand command;
            SqlDataReader dataReader;
            string sql, Output = "";

            sql = "Select Currency, Rate from dbo.Rates";

            command = new SqlCommand(sql, cnn);

            dataReader = command.ExecuteReader();

            while (dataReader.Read())
            {
                ValidateDoubleInput(dataReader.GetValue(1).ToString());
                ExchangeRates.Add(new ExchangeRate {Currency = dataReader.GetValue(0).ToString(), Rate = rateInput});
            }

            Console.WriteLine(Output);

            cnn.Close();
        }
        private bool ValidateDoubleInput(string rate)
        {
            //Validate rate entry
            if (Double.TryParse(rate, out rateInput))
            {
                return true;
            }
            else
            {
                Console.WriteLine("Invalid entry in input data file.");
                return false;
            }
        }
    }
}
