﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P2ULibrary
{
    public class ExchangeRate
    {
        public string Currency { get; set; }
        public double Rate { get; set; }
    }
}
